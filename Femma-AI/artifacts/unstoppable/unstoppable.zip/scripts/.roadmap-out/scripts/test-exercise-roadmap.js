"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const exerciseRoadmap_1 = require("../lib/exerciseRoadmap");
const result = (0, exerciseRoadmap_1.runRoadmapTests)();
console.log(`Checked ${result.checked} plans across ${result.rows} roadmap rows.`);
if (result.failed) {
    console.error(`FAILED ${result.failed} checks`);
    for (const failure of result.failures) {
        console.error(`- ${failure.combo}: ${failure.message}`);
    }
    process.exit(1);
}
console.log('All categories, times, environments, and durations returned a level-matched daily plan.');
