import { Stack } from 'expo-router';
export default function NutritionLayout() {
  return <Stack screenOptions={{ headerShown: false }}><Stack.Screen name="result" /></Stack>;
}
